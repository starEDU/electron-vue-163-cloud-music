import VueLazyLoad from 'vue3-lazyload'

export default {
    install(App){
        App.use(VueLazyLoad)
    }
}
