<template>
  <router-view/>
</template>

<style lang="less">
@import "./assets/css/cssreset.css";
@import "./assets/css/common.less";

//.primary-color{
//    color:@primary-color !important;
//}
//a{
//    color:@primary-color !important;
//
//}
</style>
