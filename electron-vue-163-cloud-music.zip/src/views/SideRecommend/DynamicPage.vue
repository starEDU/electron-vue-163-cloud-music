<template>
<h1>动态</h1>
</template>

<script>
export default {
    name: "DynamicPage"
}
</script>

<style scoped>

</style>
