<template>
<h1>私人FM</h1>
</template>

<script>
export default {
    name: "PrivateFM"
}
</script>

<style scoped>

</style>
