<template>
<h1>我的音乐云盘</h1>
</template>

<script>
export default {
    name: "MyMusicCloud"
}
</script>

<style scoped>

</style>
