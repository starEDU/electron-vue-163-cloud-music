<template>
<h1>我的收藏</h1>
</template>

<script>
export default {
    name: "MyCollection"
}
</script>

<style scoped>

</style>
