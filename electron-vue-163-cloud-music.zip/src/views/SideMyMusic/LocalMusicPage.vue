<template>
    <h1>本地音乐</h1>
</template>

<script>
export default {
    name: "LocalMusic"
}
</script>

<style scoped>

</style>
